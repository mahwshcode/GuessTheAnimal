﻿$(window).load(function () {
    $('#myModal').modal('show');
});