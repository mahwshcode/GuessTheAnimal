﻿(function () {
    "user strict";
    var appServices = function ($http) {

        var getQuestions = function () {
            return $http.get("/api/GetQuestions")
            .then(function (response) {
                return response.data;
            });
        };
        var getAnimals2 = function () {
            return $http.get("http://localhost:55956/api/Service/GetAnimals")
           .then(function (response) {
               console.log(response.data);
               return response.data;
           });
        };
        function getAllBooks() {

            return [
                {
                    "id": 1,
                    "BookName": "Goog Book",
                    "PublishYear": 2000
                },
                 {
                     "id": 2,
                     "BookName": "Goog Book2",
                     "PublishYear": 2000
                 },
                 {
                     "id": 3,
                     "BookName": "Goog Book3",
                     "PublishYear": 2000
                 }
            ]
        };

        
        return {
            getAnimals3: getAnimals2,
            getQuestions: getQuestions,
            getAllBooks: getAllBooks
        };
    };

    var app = angular.module('animalApp');
    app.factory("appServices", appServices);

})();

