﻿
(function () {
   var app = angular.module("animalApp", ["ngRoute"]);
    app.config(function ($routeProvider) {
        $routeProvider
        .when("/", {
            templateUrl: "modules/listPage.html",
            controller: "AnimalController",
            controllerAs: "vm"
        })
        .when("/questions/:animal", {
            templateUrl: "modules/questionPage.html",
            controller: "QuestionController",
            controllerAs:"quest"
        })
         .when("/Submit", {
             templateUrl: "modules/submitPage.html",
             controller: "AddAnimalController",
             controllerAs: "add"
            
         })
        .otherwise({ redirectTo: "/" });

    });
})();