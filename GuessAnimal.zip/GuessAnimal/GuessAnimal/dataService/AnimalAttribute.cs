﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace GuessAnimal.dataService
{
    [DataContract]
    public class AnimalAttribute
    {
        [DataMember]
        public string animalName { get; set; }
        [DataMember]
        public string animalDescription { get; set; }
        public AnimalAttribute(string _animalName, string _animalDescription)
        {
            animalName = _animalName;
            animalDescription = _animalDescription;
        }
    }
    [DataContract]
    public class Questions
    {
        [DataMember]
        public string question { get; set; }
        public Questions(string _question)
        {
            question = _question;
            
        }
    } 
}