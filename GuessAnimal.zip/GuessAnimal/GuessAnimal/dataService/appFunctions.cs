﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Web;

namespace GuessAnimal.dataService
{
    public static class appFunctions
    {
        public static MemoryCache cache = MemoryCache.Default;
        public static List<AnimalAttribute> AnimalList()
        {
            List<AnimalAttribute> animalList = new List<AnimalAttribute>();
          
            animalList.Add(new AnimalAttribute("Elephant", ";has a trunk, trumpets and is grey"));
            animalList.Add(new AnimalAttribute("Lion", ";has a trunk, trumpets and is grey"));
            animalList.Add(new AnimalAttribute("Dog", ";has a nose, legs and is black"));
            animalList.Add(new AnimalAttribute("Duck", ";has a eye, test and is white"));
            animalList.Add(new AnimalAttribute("Snake", ";has a nose , test and is long"));
            animalList.Add(new AnimalAttribute("Horse", ";has a tail, skin and is white"));
            animalList.Add(new AnimalAttribute("Lion", ";has a trunk, trumpets and is grey"));
            return animalList;
        }
        public static List<Questions> QuestionsforUser()
        {
            List<Questions> questionList = new List<Questions>();

            questionList.Add(new Questions("Do you like this animal?" ));
            questionList.Add(new Questions("Have you ever sceen this animal in the zoo?"));
            questionList.Add(new Questions("How many legs it has?"));
            questionList.Add(new Questions("what is the skin color of animal?"));

            return questionList;
        }

        public static List<AnimalAttribute> GetAnimalFromCache()
        {
            List<AnimalAttribute> animal;          
            animal = (List<AnimalAttribute>)cache.Get("animals");
            
            if (cache["animals"] == null)
            {
                animal = AnimalList();

                cache.Add("animals", animal,new CacheItemPolicy());
            }

            return animal;
        }
        public static bool AddNewItem(string name,string description)
        {
            List<AnimalAttribute> animal;
            animal = (List<AnimalAttribute>)cache.Get("animals");
            animal.Add(new AnimalAttribute(name, description));

            cache.Add("animals", animal, new CacheItemPolicy());
            return true;
        }
       
    }
}