﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GuessAnimal.dataService
{
    [RoutePrefix("api/Service")]
    public class ServiceController : ApiController
    {


        [Route("GetAnimals")]
        [HttpGet]
        public IHttpActionResult GetAnimals()
        {
            IEnumerable<AnimalAttribute> list = appFunctions.GetAnimalFromCache();
           
            if (list == null)
            {
                return NotFound(); // Returns a NotFoundResult
            }
            return Ok(list);  // Returns an OkNegotiatedContentResult

        }
        [Route("QuestionsGET")]
        [HttpGet]
        public IHttpActionResult Questions()
        {
            IEnumerable<Questions> list = appFunctions.QuestionsforUser();

            if (list == null)
            {
                return NotFound(); // Returns a NotFoundResult
            }
            return Ok(list);  // Returns an OkNegotiatedContentResult

        }
        [Route("AddNewAnimal")]
        [HttpPost]
        public IHttpActionResult AddNewAnimal([FromBody]AnimalAttribute animal)
        {
            bool status= appFunctions.AddNewItem(animal.animalName, animal.animalDescription);
            if (status == false)
            {
                return NotFound(); // Returns a NotFoundResult
            }
            return Ok(status);
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}