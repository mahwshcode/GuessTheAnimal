﻿/// <reference path="scripts/_references.js" />
(function () {
    
    angular.module("animalApp").controller("AnimalController", ["$http", AnimalController]);
    function AnimalController( $http) {
        var vm = this;
        vm.appName = "test";
        vm.occurrenceOptions = [];
        
       
        $http.get("/api/Service/GetAnimals")
             .then(function (response) {
               
               
                 for (i = 0; i < response.data.length; i++) {
                    
                     vm.occurrenceOptions.push(response.data[i]);
                 }
                
             });
      
        vm.submitResult = function (result) {
           
            vm.selectedOption = result;
    
  };

        
      
       
    };

})();