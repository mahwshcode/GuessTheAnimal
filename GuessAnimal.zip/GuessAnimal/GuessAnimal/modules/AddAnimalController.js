﻿/// <reference path="scripts/_references.js" />
(function () {

    angular.module("animalApp")
        .controller("AddAnimalController", ["$http", AddAnimalController]);

    function AddAnimalController($http) {
        var add = this;
        add.message = "";
      

        add.submit = function () {
          var animal = {
              animalName: add.animalName,
              animalDescription: add.animalDescription
        };
          $http({
                method: "POST",
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                url: '/api/Service/AddNewAnimal',
                data:animal 
            })
           .then(function (response) {
               add.message = "Your animal has addded.Thank You"
               // success
           },
            function (response) { // optional
                console.log(response);
            });

        };










    };

})();