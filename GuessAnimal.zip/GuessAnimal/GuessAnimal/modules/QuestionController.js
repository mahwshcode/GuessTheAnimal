﻿/// <reference path="scripts/_references.js" />
(function () {

    angular.module("animalApp")
        .controller("QuestionController", ["$http", "$routeParams", QuestionController]);

    function QuestionController($http, $routeParams) {
        var quest = this;
        quest.appName = $routeParams.animal;
        quest.QuestionOptions = [];
        quest.selectedOption = "select";

        $http.get("/api/Service/Questions")
             .then(function (response) {
               for (i = 0; i < response.data.length; i++) {
                    quest.QuestionOptions.push(response.data[i]);
                     
                 }

             });

    




    };

})();